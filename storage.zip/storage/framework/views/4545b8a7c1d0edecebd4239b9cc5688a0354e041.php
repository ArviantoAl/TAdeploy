

<?php $__env->startSection('content'); ?>
    <!-- breadcrumb -->
    <div class="breadcrumb-header justify-content-between">
        <div class="left-content">
            <span class="main-content-title mg-b-0 mg-b-lg-1">Daftar User</span>
        </div>
        <div class="justify-content-center mt-2">
            <ol class="breadcrumb">
                <li class="breadcrumb-item tx-15"><a href="javascript:void(0);">Data User</a></li>
                <li class="breadcrumb-item active" aria-current="page">Daftar User</li>
            </ol>
        </div>
    </div>
    <!-- /breadcrumb -->

    <!-- Row -->
    <div class="row row-sm">
        <div class="col-lg-12">
            <div class="btn-group ms-2 mt-2 mb-2">
                
            </div>
            <div class="card custom-card overflow-hidden">
                <div class="card-body">
                    <?php if(session()->has('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <strong><?php echo e(session()->get('success')); ?></strong>
                            <button aria-label="Close" class="btn-close" data-bs-dismiss="alert" type="button"><span
                                    aria-hidden="true">&times;</span></button>
                        </div>
                    <?php endif; ?>
                    <div class="table-responsive">
                        <table class="table table-bordered table-md">
                            <thead>
                                <th>No</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Username</th>
                                <th>Role</th>
                                <th>Action</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($no + 1); ?></td>
                                        <td><?php echo e($user->name); ?></td>
                                        <td><?php echo e($user->email); ?></td>
                                        <td><?php echo e($user->username); ?></td>
                                        <td><?php echo e($user->role->nama_role); ?></td>
                                        <td>
                                            <div class="btn-group" role="group" aria-label="Basic example">
                                                <a href="<?php echo e(url('admin/user/' . $user->id_user . '/update-role')); ?>"
                                                    class="btn
                                                    btn-info">Edit
                                                    Role</a>
                                                <a href="<?php echo e(url('admin/user/' . $user->id_user . '/update')); ?>"
                                                    class="btn
                                                    btn-warning">Edit</a>
                                                <a href="<?php echo e(url('admin/user/' . $user->id_user . '/delete')); ?>"
                                                    onClick="return confirm('Hapus user ini?')"
                                                    class="btn
                                                    btn-danger">Delete</a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="row justify-content-center">
                        <div class="buttons">
                            <nav aria-label="Page navigation example">
                                <ul class="pagination">
                                    <li class="<?php echo e($users->currentPage() == 1 ? 'page-item disabled' : 'page-item'); ?>">
                                        <a class="page-link" href="<?php echo e($users->url($users->currentPage() - 1)); ?>"
                                            aria-label="Previous">
                                            <span aria-hidden="true">&laquo;</span>
                                            <span class="sr-only">Previous</span>
                                        </a>
                                    </li>
                                    <?php for($i = 1; $i <= $users->lastPage(); $i++): ?>
                                        <li class="<?php echo e($users->currentPage() == $i ? 'page-item active' : 'page-item'); ?>">
                                            <a class="page-link" href="<?php echo e($users->url($i)); ?>"><?php echo e($i); ?></a>
                                        </li>
                                    <?php endfor; ?>
                                    <li
                                        class="<?php echo e($users->currentPage() == $users->lastPage() ? 'page-item disabled' : 'page-item'); ?>">
                                        <a class="page-link" href="<?php echo e($users->url($users->currentPage() + 1)); ?>"
                                            aria-label="Next">
                                            <span aria-hidden="true">&raquo;</span>
                                            <span class="sr-only">Next</span>
                                        </a>
                                    </li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.nowa', [
    'titlePage' => __('Daftar User'),
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppa\htdocs\cv_gmp\resources\views/dashboard/admin/users/user.blade.php ENDPATH**/ ?>