

<?php $__env->startSection('content'); ?>
    <!-- breadcrumb -->
    <div class="breadcrumb-header justify-content-between">
        <div class="left-content">
            <span class="main-content-title mg-b-0 mg-b-lg-1">Daftar Perangkat BTS</span>
        </div>
        <div class="justify-content-center mt-2">
            <ol class="breadcrumb">
                <li class="breadcrumb-item tx-15"><a href="javascript:void(0);">Data Perangkat BTS</a></li>
                <li class="breadcrumb-item active" aria-current="page">Daftar Perangkat BTS</li>
            </ol>
        </div>
    </div>
    <!-- /breadcrumb -->

    <!-- Row -->
    <div class="row row-sm">
        <div class="col-lg-12">
            <div class="btn-group ms-2 mt-2 mb-2">
                <a class="btn btn-success" href="<?php echo e(route('teknisi.tambahbts')); ?>">
                    Tambah Perangkat BTS
                </a>
            </div>
            <div class="card custom-card overflow-hidden">
                <div class="card-body">
                    <?php if(session()->has('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <strong><?php echo e(session()->get('success')); ?></strong>
                            <button aria-label="Close" class="btn-close" data-bs-dismiss="alert" type="button"><span aria-hidden="true">&times;</span></button>
                        </div>
                    <?php endif; ?>
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped mg-b-0 text-md-nowrap">
                            <thead style="text-align: center">
                            <tr>
                                <th>No</th>
                                <th>Nama Perangkat</th>
                                <th>BTS</th>
                                <th>Kategori Frekuensi</th>
                                <th>Jenis</th>
                                <th>Frekuensi</th>
                                <th>SSID</th>
                                <th>IP</th>
                                <th>Status</th>
                                <th colspan="2">Action</th>
                            </tr>
                            </thead>
                            <tbody style="text-align: center">
                            <?php $__currentLoopData = $btss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $bts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($no+1); ?></td>
                                    <td><?php echo e($bts->nama_bts); ?></td>
                                    <td><?php echo e($bts->lokasi->nama_master); ?></td>
                                    <td><?php echo e($bts->kategori->kategori_frekuensi); ?></td>
                                    <td><?php echo e($bts->jenis->nama_perangkat); ?></td>
                                    <td><?php echo e($bts->frekuensi); ?></td>
                                    <td><?php echo e($bts->ssid); ?></td>
                                    <td><?php echo e($bts->ip); ?></td>
                                    <?php if($bts->status_id == 3): ?>
                                        <td>
                                            <h5>
                                                <span class="badge badge-pill bg-success me-1"><?php echo e($bts->status->nama_status); ?></span>
                                            </h5>
                                        </td>
                                        <?php if($bts->jenis_id == 4): ?>
                                            <td>
                                            <a class="btn btn-warning" href="<?php echo e(route('teknisi.geteditloginbts', $bts->id_bts)); ?>" data-toggle="tooltip" title="Edit">
                                                <i class="fa fa-edit"></i>
                                            </a>
                                            </td>
                                        <?php else: ?>
                                            <td>
                                                <a class="btn btn-warning" href="<?php echo e(route('teknisi.editbts', $bts->id_bts)); ?>" data-toggle="tooltip" title="Edit">
                                                    <i class="fa fa-edit"></i>
                                                </a>
                                            </td>
                                        <?php endif; ?>
                                        <td>
                                            <a class="btn btn-danger" href="<?php echo e(route('admin.nonaktifbts', $bts->id_bts)); ?>" data-toggle="tooltip" title="Nonaktif">
                                                <i class="fa fa-ban"></i>
                                            </a>
                                        </td>
                                    <?php elseif($bts->status_id == 4): ?>
                                        <td>
                                            <h5>
                                                <span class="badge badge-pill bg-danger me-1"><?php echo e($bts->status->nama_status); ?></span>
                                            </h5>
                                        </td>
                                        <td>
                                            <a class="btn btn-success" href="<?php echo e(route('admin.aktifbts', $bts->id_bts)); ?>" data-toggle="tooltip" title="Aktifkan">
                                                <i class="fa fa-check"></i>
                                            </a>
                                        </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php echo e($btss->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.nowa',[
    'titlePage' => __('Daftar Perangkat BTS'),
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppa\htdocs\cv_gmp\resources\views/dashboard/teknisi/bts/index.blade.php ENDPATH**/ ?>