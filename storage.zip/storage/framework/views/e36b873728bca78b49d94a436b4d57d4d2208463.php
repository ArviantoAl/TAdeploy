<?php echo e($slot); ?>

<?php /**PATH C:\xamppa\htdocs\cv_gmp\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>