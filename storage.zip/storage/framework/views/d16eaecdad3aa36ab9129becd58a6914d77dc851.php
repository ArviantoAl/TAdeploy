

<?php $__env->startSection('content'); ?>
    <!-- breadcrumb -->
    <div class="breadcrumb-header justify-content-between">
        <div class="left-content">
            <span class="main-content-title mg-b-0 mg-b-lg-1">Detail Pelanggan </span>
        </div>
        <div class="justify-content-center mt-2">
            <ol class="breadcrumb">
                <li class="breadcrumb-item tx-15"><a href="javascript:void(0);">Data Pelanggan</a></li>
                <li class="breadcrumb-item active" aria-current="page">Detail Pelanggan</li>
            </ol>
        </div>
    </div>
    <!-- /breadcrumb -->

    <div class="col-lg-12 col-xl-12 col-md-12 col-sm-12">
        <div class="card  box-shadow-0 ">
            <div class="card-header">
                <h4 class="card-title mb-1">Detail Pelanggan</h4>
            </div>
            <div class="card-body pt-0">
                <form method="POST" action="<?php echo e(route('teknisi.detailpelangganaktif')); ?>">
                    <form>
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('GET'); ?>
                    
                    <div class="row">
                        <div class="form-group col-6">
                            <label for="alamat_pasang" class="form-label">alamat_pasang</label>
                            <input class="form-control" id="alamat_pasang" name="alamat_pasang" value="<?php echo e($langganan->alamat_pasang ?? 'None'); ?>"
                                placeholder="" type="text" autofocus>
                        </div>
                        <div class="form-group col-6">
                            <label for="nama_layanan" class="form-label">Jenis Langganan</label>
                            <input class="form-control" id="nama_layanan" name="nama_layanan" value="<?php echo e($langganan->layanan->nama_layanan ?? 'None'); ?>"
                                placeholder="" type="text" autofocus>
                        </div>
                        <div class="form-group col-6">
                            <label for="ip" class="form-label">IP Address</label>
                            <input class="form-control" id="ip" name="ip" value="<?php echo e($langganan->IP ?? 'None'); ?>"
                                placeholder="" type="text" autofocus>
                        </div>
                        <div class="form-group col-6">
                            <label for="tgl_lanjut" class="form-label">Tanggal Expired</label>
                            <input class="form-control" id="tgl_lanjut" name="tgl_lanjut" value="<?php echo e($langganan->tgl_lanjut ?? 'None'); ?>"
                                placeholder="" type="text" autofocus>
                        </div>
                        
                        
                    </div>
                    
                    <button type="submit" onclick='window.location.reload();'>PING</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.nowa', [
    'titlePage' => __('Detail Pelanggan Aktif'),
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppa\htdocs\cv_gmp\resources\views/dashboard/teknisi/user/detail_pelanggan.blade.php ENDPATH**/ ?>