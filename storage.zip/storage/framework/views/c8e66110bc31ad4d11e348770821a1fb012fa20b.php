

<?php $__env->startSection('content'); ?>
    <div class="page-single">
        <div class="container">
            <div class="row">
                <div class="col-xl-5 col-lg-6 col-md-8 col-sm-8 col-xs-10 card-sigin-main py-4 justify-content-center mx-auto">
                    <div class="card-sigin">
                        <!-- Demo content-->
                        <div class="main-card-signin d-md-flex">
                            <div class="wd-100p">
                                <div class="mb-3 d-flex"> <a href="index.html"><img src="<?php echo e(asset('nowa_assets')); ?>/img/brand/favicon.png" class="sign-favicon ht-40" alt="logo"></a></div>
                                <div class="main-card-signin d-md-flex bg-white">
                                    <div class="wd-100p">
                                        <div class="main-signin-header">
                                            <h2>Forgot Password!</h2>
                                            <h4>Please Enter Your Email</h4>
                                            <form method="POST" action="<?php echo e(route('password.email')); ?>">
                                                <?php echo csrf_field(); ?>
                                                <div class="form-group">
                                                    <label for="email"><?php echo e(__('Email Address')); ?></label>
                                                    <input id="email" type="email" placeholder="Your email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
                                                </div>
                                                <button type="submit" class="btn btn-primary btn-block">Send</button>
                                            </form>
                                        </div>
                                        <div class="main-signup-footer mg-t-20 text-center">
                                            <p>Forget it, <a href="<?php echo e(route('login')); ?>"> Send me back</a> to the sign in screen.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.nowa',[
    'titlePage' => __('Reset')
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppa\htdocs\cv_gmp\resources\views/auth/passwords/email.blade.php ENDPATH**/ ?>