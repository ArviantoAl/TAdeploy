

<?php $__env->startSection('content'); ?>
    <div class="page-single">
        <div class="container">
            <div class="row">
                <div class="col-xl-5 col-lg-6 col-md-8 col-sm-8 col-xs-10 card-sigin-main mx-auto my-auto py-4 justify-content-center">
                    <div class="card-sigin">
                        <!-- Demo content-->
                        <div class="main-card-signin d-md-flex">
                            <div class="wd-100p"><div class="d-flex mb-4"><a href=""><img src="<?php echo e(asset('nowa_assets')); ?>/img/brand/logo.png" class="sign-favicon ht-80" alt="logo"></a></div>
                                <div class="">
                                    <div class="main-signup-header">
                                        <h2>Welcome back!</h2>
                                        <h6 class="font-weight-semibold mb-4">Please sign in to continue.</h6>
                                        <div class="panel panel-primary">
                                            <?php if(session()->has('error')): ?>
                                                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                                    <strong><?php echo e(session()->get('error')); ?></strong>
                                                    <button aria-label="Close" class="btn-close" data-bs-dismiss="alert" type="button"><span aria-hidden="true">&times;</span></button>
                                                </div>
                                            <?php endif; ?>
                                            <div class="panel-body tabs-menu-body border-0 p-3">
                                                <div class="tab-content">
                                                    <div class="tab-pane active">
                                                        <form method="POST" action="<?php echo e(route('login')); ?>">
                                                            <?php echo csrf_field(); ?>
                                                            <div class="form-group">
                                                                <label for="username"><?php echo e(__('No Hp atau Email')); ?></label>
                                                                <input id="username" placeholder="Username atau Email" type="text" class="form-control <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="username" value="<?php echo e(old('username')); ?>" required autocomplete="username" autofocus>

                                                            </div>
                                                            <div class="form-group">
                                                                <label for="password"><?php echo e(__('Password')); ?></label>
                                                                <input id="password" placeholder="Password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password">
                                                            </div>
                                                            <button type="submit" class="btn btn-primary btn-block">Login</button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="main-signin-footer text-center mt-3">
                                            <p><a href="<?php echo e(route('password.request')); ?>" class="mb-3">Forgot password?</a></p>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.nowa',[
    'titlePage' => __('Login Page')
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppa\htdocs\cv_gmp_ku\resources\views/auth/login.blade.php ENDPATH**/ ?>