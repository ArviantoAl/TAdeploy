---
title: Bezier
categories:
  - Graphics
tags:
  - graphics
  - vector
  - pen
---
