---
title: Arrow down left circle fill
layout: icon
categories:
  - Shape Arrows
tags:
  - arrow
  - circle
---
