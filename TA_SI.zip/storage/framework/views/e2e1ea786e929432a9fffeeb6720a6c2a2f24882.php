<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="col-12 col-lg-12">
            <div class="card">
                <div class="card-header">
                    <h4><?php echo e($header); ?></h4>
                </div>

                <div class="card-body">
                    <div class="table-responsive">
                        <?php if(count($langganans)==0): ?>
                            <p>Tidak ada data</p>
                        <?php elseif(count($langganans)>0): ?>
                            <table class="table table-bordered table-md">
                                <thead>
                                <th>No</th>
                                <th>Nama Pelanggan</th>
                                <th>Alamat Pemasangan</th>
                                <th>Jenis Langganan</th>
                                <th>Tanggal Expired</th>
                                <th>Status</th>
                                <th>Aksi</th>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $langganans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $langganan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($no+1); ?></td>
                                        <td><?php echo e($langganan->pelanggan->name); ?></td>
                                        <td><?php echo e($langganan->alamat_pasang); ?></td>
                                        <td><?php echo e($langganan->layanan->nama_layanan); ?></td>
                                        <td><?php echo e($langganan->tgl_lanjut); ?></td>
                                        <?php if($langganan->status == 0): ?>
                                            <td><div class="badge badge-info">Langganan Baru</div></td>
                                            <td>
                                                <a class="btn btn-success" href="<?php echo e(route('administrator.approvelangganan', $langganan->id_langganan)); ?>">Setuju</a>

                                                <a class="btn btn-danger" href="<?php echo e(route('administrator.rejectlangganan', $langganan->id_langganan)); ?>">Tolak</a>
                                            </td>
                                        <?php elseif($langganan->status == 1): ?>
                                            <td><div class="badge badge-danger">Langganan Dibatalkan</div></td>
                                        <?php elseif($langganan->status == 2): ?>
                                            <td><div class="badge badge-warning">Langganan Disetujui</div></td>
                                        <?php elseif($langganan->status == 3): ?>
                                            <td><div class="badge badge-warning">Menunggu pembayaran</div></td>
                                        <?php elseif($langganan->status == 4): ?>
                                            <?php if($today >= $langganan->tgl_lanjut): ?>
                                                <td><div class="badge badge-danger">Langganan Kadaluarsa</div></td>
                                                <td>
                                                    <a class="btn btn-warning" href="<?php echo e(route('administrator.approvelangganan', $langganan->id_langganan)); ?>">Ajukan Pengaktifan</a>
                                                </td>
                                            <?php else: ?>
                                                <td><div class="badge badge-success">Langganan Aktif</div></td>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app',[
    'titlePage' => __('Daftar Langganan'),
    'sub' => $header
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\borota\pendataan-pelanggan\resources\views/dashboard/administrator/langganan.blade.php ENDPATH**/ ?>