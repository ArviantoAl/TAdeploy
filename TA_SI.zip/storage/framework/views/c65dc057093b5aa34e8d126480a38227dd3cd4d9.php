<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="col-12 col-lg-12">
            <div class="card">
                <div class="card-header">
                    <h4>Daftar Layanan</h4>
                </div>

                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-md">
                            <thead>
                            <th>No</th>
                            <th>Kategori Layanan</th>
                            <th>Jenis Layanan</th>
                            <th>Harga</th>
                            <th colspan="2">Action</th>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $layanans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $layanan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($no+1); ?></td>
                                    <td><?php echo e($layanan->kategori->nama_kategori); ?></td>
                                    <td><?php echo e($layanan->nama_layanan); ?></td>
                                    <td><?php echo e($layanan->harga); ?></td>
                                    <td>
                                        <a class="btn btn-warning" href="<?php echo e(route('administrator.editlayanan', $layanan->id_layanan)); ?>">Edit</a>
                                    </td>
                                    <td>
                                        <form action="<?php echo e(route('administrator.deletelayanan', $layanan->id_layanan)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="_method" value="DELETE">
                                            <button class="btn btn-danger" type="submit">DELETE</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <a class="btn btn-success" href="<?php echo e(route('administrator.tambahlayanan')); ?>">Tambah Kategori</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app',[
    'titlePage' => __('Daftar Layanan'),
    'sub' => ' '
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\borota\pendataan-pelanggan\resources\views/dashboard/administrator/layanan/layanan.blade.php ENDPATH**/ ?>