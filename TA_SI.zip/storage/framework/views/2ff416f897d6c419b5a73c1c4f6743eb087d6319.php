<div class="main-sidebar">
    <aside id="sidebar-wrapper">
        <div class="sidebar-brand">
            <a href="index.html">Stisla</a>
        </div>
        <div class="sidebar-brand sidebar-brand-sm">
            <a href="index.html">St</a>
        </div>
        <ul class="sidebar-menu">
            <li class="menu-header">User</li>
            <?php if($titlePage == 'Daftar User'|| $titlePage == 'Tambah User'): ?>
                <li class="nav-item dropdown active">
            <?php else: ?>
                <li class="nav-item dropdown">
            <?php endif; ?>
                <a href="#" class="nav-link has-dropdown"><i class="fas fa-users"></i><span>Data User</span></a>
                <ul class="dropdown-menu">
                    <?php if($titlePage == 'Daftar User'): ?>
                        <li class="active">
                    <?php else: ?>
                        <li>
                    <?php endif; ?>
                    <a class="nav-link" href="<?php echo e(route('admin.user')); ?>">Daftar User</a></li>
                        <?php if($titlePage == 'Tambah User'): ?>
                            <li class="active">
                        <?php else: ?>
                            <li>
                        <?php endif; ?>
                    <a class="nav-link" href="<?php echo e(route('admin.tambahuser')); ?>">Tambah User</a></li>
                </ul>
            </li>

            <li class="menu-header">Layanan dan Kategori</li>
                <?php if($titlePage == 'Daftar Kategori'|| $titlePage == 'Tambah Kategori'): ?>
                    <li class="nav-item dropdown active">
                <?php else: ?>
                    <li class="nav-item dropdown">
                <?php endif; ?>
                <a href="#" class="nav-link has-dropdown"><i class="fas fa-tag"></i> <span>Kategori</span></a>
                <ul class="dropdown-menu">
                    <?php if($titlePage == 'Daftar Kategori'): ?>
                        <li class="active">
                    <?php else: ?>
                        <li>
                    <?php endif; ?>
                    <a class="nav-link" href="<?php echo e(route('admin.kategori')); ?>">Daftar Kategori</a></li>
                        <?php if($titlePage == 'Tambah Kategori'): ?>
                            <li class="active">
                        <?php else: ?>
                            <li>
                        <?php endif; ?>
                    <a class="nav-link" href="<?php echo e(route('admin.tambahkategori')); ?>">Tambah Kategori</a></li>
                </ul>
            </li>
                    <?php if($titlePage == 'Daftar Layanan'|| $titlePage == 'Tambah Layanan'|| $titlePage == 'Edit Layanan'): ?>
                        <li class="nav-item dropdown active">
                    <?php else: ?>
                        <li class="nav-item dropdown">
                    <?php endif; ?>
                <a href="#" class="nav-link has-dropdown"><i class="fa fa-cloud"></i> <span>Layanan</span></a>
                <ul class="dropdown-menu">
                    <?php if($titlePage == 'Daftar Layanan'): ?>
                        <li class="active">
                    <?php else: ?>
                        <li>
                    <?php endif; ?>
                    <a class="nav-link" href="<?php echo e(route('admin.layanan')); ?>">Daftar Layanan</a></li>
                        <?php if($titlePage == 'Tambah Layanan'): ?>
                            <li class="active">
                        <?php else: ?>
                            <li>
                        <?php endif; ?>
                    <a class="nav-link" href="<?php echo e(route('admin.tambahlayanan')); ?>">Tambah Layanan</a></li>
                </ul>
            </li>

            <li class="menu-header">Langganan dan Invoice</li>
                <?php if($titlePage == 'Daftar Langganan'): ?>
                    <li class="nav-item dropdown active">
                <?php else: ?>
                    <li class="nav-item dropdown">
                <?php endif; ?>
                <a href="#" class="nav-link has-dropdown"><i class="fa fa-satellite-dish"></i> <span>Langganan</span></a>
                <ul class="dropdown-menu">
                    <?php if($sub == 'Semua Langganan'): ?>
                        <li class="active">
                    <?php else: ?>
                        <li>
                    <?php endif; ?>
                    <a href="<?php echo e(route('admin.langganan')); ?>">Semua Langganan</a></li>
                        <?php if($sub == 'Langganan Baru'): ?>
                            <li class="active">
                        <?php else: ?>
                            <li>
                        <?php endif; ?>
                    <a href="<?php echo e(route('admin.langgananbaru')); ?>">Baru</a></li>
                            <?php if($sub == 'Langganan Disetujui'): ?>
                                <li class="active">
                            <?php else: ?>
                                <li>
                            <?php endif; ?>
                    <a href="<?php echo e(route('admin.langganansetuju')); ?>">Disetujui</a></li>
                                <?php if($sub == 'Langganan Menunggu Pembayaran'): ?>
                                    <li class="active">
                                <?php else: ?>
                                    <li>
                                <?php endif; ?>
                    <a href="<?php echo e(route('admin.langgananmenunggu')); ?>">Menunggu Pembayaran</a></li>
                                    <?php if($sub == 'Langganan Aktif'): ?>
                                        <li class="active">
                                    <?php else: ?>
                                        <li>
                                    <?php endif; ?>
                    <a href="<?php echo e(route('admin.langgananaktif')); ?>">Aktif</a></li>
                                        <?php if($sub == 'Langganan Kadaluarsa'): ?>
                                            <li class="active">
                                        <?php else: ?>
                                            <li>
                                        <?php endif; ?>
                    <a href="<?php echo e(route('admin.langganankadaluarsa')); ?>">Kadaluarsa</a></li>
                                            <?php if($sub == 'Langganan Batal'): ?>
                                                <li class="active">
                                            <?php else: ?>
                                                <li>
                                            <?php endif; ?>
                    <a href="<?php echo e(route('admin.langgananbatal')); ?>">Batal</a></li>
                </ul>
            </li>
                            <?php if($titlePage == 'Daftar Invoice'): ?>
                                <li class="nav-item dropdown active">
                            <?php else: ?>
                                <li class="nav-item dropdown">
                            <?php endif; ?>
                <a href="#" class="nav-link has-dropdown"><i class="fa fa-file-invoice"></i> <span>Invoice</span></a>
                <ul class="dropdown-menu">
                    <?php if($sub == 'Semua Invoice'): ?>
                        <li class="active">
                    <?php else: ?>
                        <li>
                    <?php endif; ?>
                    <a href="<?php echo e(route('admin.invoice')); ?>">Semua Invoice</a></li>
                        <?php if($sub == 'Invoice Belum Dikirim'): ?>
                            <li class="active">
                        <?php else: ?>
                            <li>
                        <?php endif; ?>
                    <a href="<?php echo e(route('admin.inv_belumkirim')); ?>">Belum Dikirim</a></li>
                            <?php if($sub == 'Invoice Melebihi Batas Pembayaran'): ?>
                                <li class="active">
                            <?php else: ?>
                                <li>
                            <?php endif; ?>
                    <a href="<?php echo e(route('admin.inv_melebihibatas')); ?>">Melebihi Batas Bayar</a></li>
                                <?php if($sub == 'Invoice Menunggu Pembayaran'): ?>
                                    <li class="active">
                                <?php else: ?>
                                    <li>
                                <?php endif; ?>
                    <a href="<?php echo e(route('admin.inv_menunggu')); ?>">Menunggu Pembayaran</a></li>
                                    <?php if($sub == 'Invoice Lunas'): ?>
                                        <li class="active">
                                    <?php else: ?>
                                        <li>
                                    <?php endif; ?>
                    <a href="<?php echo e(route('admin.inv_lunas')); ?>">Lunas</a></li>
                                        <?php if($sub == 'Invoice Tidak Dibayar/Batal'): ?>
                                            <li class="active">
                                        <?php else: ?>
                                            <li>
                                        <?php endif; ?>
                    <a href="<?php echo e(route('admin.inv_batal')); ?>">Tidak Dibayar/Batal</a></li>
                </ul>
            </li>
        </ul>
    </aside>
</div>
<?php /**PATH C:\Users\borota\pendataan-pelanggan\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>