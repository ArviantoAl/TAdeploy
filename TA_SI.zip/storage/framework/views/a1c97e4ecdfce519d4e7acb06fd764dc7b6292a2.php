<?php $__env->startSection('content'); ?>
    <!-- breadcrumb -->
    <div class="breadcrumb-header justify-content-between">
        <div class="left-content">
            <span class="main-content-title mg-b-0 mg-b-lg-1">Daftar Pelanggan <?php echo e($nama_status); ?></span>
        </div>
        <div class="justify-content-center mt-2">
            <ol class="breadcrumb">
                <li class="breadcrumb-item tx-15"><a>Data Pelanggan</a></li>
                <li class="breadcrumb-item active" aria-current="page">Daftar Pelanggan <?php echo e($nama_status); ?></li>
            </ol>
        </div>
    </div>
    <!-- /breadcrumb -->

    <!-- Row -->
    <div class="row row-sm">
        <div class="col-lg-12">
            <?php if($terakhir == $bulan): ?>
                <form action="<?php echo e(route('admin.kirimsemua')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row row-xs">
                        <div class="col-md-4">
                            <div class="input-group">
                                <div class="input-group-text">
                                    Jatuh Tempo:
                                </div>
                                <input class="form-control" type="datetime-local" name="tempo" required>
                            </div>
                        </div>
                        <div class="form-group col-md-3">
                            <button type="submit" class="btn btn-primary btn-block">Kirim Invoice Bulan <?php echo e($namabulan); ?></button>
                        </div>
                    </div>
                </form>
            <?php endif; ?>

            <form action="<?php echo e(route('admin.caripelanggan')); ?>" method="GET">
                <div class="row row-xs">
                    <div class="form-group col-md-2">
                        <select name="status" id="status" class="form-control form-select select2" data-placeholder="Filter status">
                            <option value="all" <?php echo e($nama_status == 'Semua' ? 'selected' : ''); ?>>Semua</option>
                            <option value="3" <?php echo e($nama_status == 'Aktif' ? 'selected' : ''); ?>>Aktif</option>
                            <option value="1" <?php echo e($nama_status == 'On Progress' ? 'selected' : ''); ?>>On Progress</option>
                            <option value="2" <?php echo e($nama_status == 'Pending' ? 'selected' : ''); ?>>Pending</option>
                            <option value="4" <?php echo e($nama_status == 'Non Aktif' ? 'selected' : ''); ?>>Nonaktif</option>
                        </select>
                    </div>
                    <div class="form-group col-md-3">
                        <input type="search" name="search" class="form-control" placeholder="Search...">
                    </div>
                    <div class="form-group col-md-1">
                        <button type="submit" id="search" class="btn btn-primary btn-block">search</button>
                    </div>
                </div>
            </form>
            <div class="card custom-card overflow-hidden">
                <div class="card-body">
                    <?php if(session()->has('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <strong><?php echo e(session()->get('success')); ?></strong>
                            <button aria-label="Close" class="btn-close" data-bs-dismiss="alert" type="button"><span aria-hidden="true">&times;</span></button>
                        </div>
                    <?php endif; ?>
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped mg-b-0 text-md-nowrap">
                            <thead style="text-align: center">
                            <tr>
                                <th>No</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Username/No Hp</th>
                                <th>Role</th>
                                <th>PPN</th>
                                <th>Status</th>
                                <th colspan="4">Action</th>
                            </tr>
                            </thead>
                            <tbody style="text-align: center">
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($no+1); ?></td>
                                    <td><?php echo e($user->name); ?></td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td><?php echo e($user->username); ?></td>
                                    <td><?php echo e($user->role->nama_role); ?></td>
                                    <td>
                                        <input id="ppn" class="checkbox" data-id="<?php echo e($user->id_user); ?>" type="checkbox" <?php echo e($user->ppn != 0 ? 'checked' : ''); ?>>
                                    </td>
                                    <?php if($user->status_id == 1): ?>
                                        <td>
                                            <h5>
                                                <span class="badge badge-pill bg-primary me-1"><?php echo e($user->status->nama_status); ?></span>
                                            </h5>
                                        </td>
                                    <?php elseif($user->status_id == 2): ?>
                                        <td>
                                            <h5>
                                                <span class="badge badge-pill bg-warning me-1"><?php echo e($user->status->nama_status); ?></span>
                                            </h5>
                                        </td>
                                        <td>
                                            <a class="btn btn-warning" href="<?php echo e(route('admin.form_lama', $user->id_user)); ?>" data-toggle="tooltip" title="Tambah Langganan">
                                                <i class="fa fa-plus"></i>
                                            </a>
                                        </td>
                                        <td>
                                            <a class="btn btn-warning" href="<?php echo e(route('admin.edituser', $user->id_user)); ?>" data-toggle="tooltip" title="Edit">
                                                <i class="fa fa-edit"></i>
                                            </a>
                                        </td>
                                    <?php elseif($user->status_id == 3): ?>
                                        <td>
                                            <h5>
                                                <span class="badge badge-pill bg-success me-1"><?php echo e($user->status->nama_status); ?></span>
                                            </h5>
                                        </td>
                                        <td>
                                            <a class="btn btn-warning" href="<?php echo e(route('admin.form_lama', $user->id_user)); ?>" data-toggle="tooltip" title="Tambah Langganan">
                                                <i class="fa fa-plus"></i>
                                            </a>
                                        </td>
                                        <td>
                                            <a class="btn btn-warning" href="<?php echo e(route('admin.edituser', $user->id_user)); ?>" data-toggle="tooltip" title="Edit">
                                                <i class="fa fa-edit"></i>
                                            </a>
                                        </td>
                                        <td>
                                            <a class="btn btn-danger" href="<?php echo e(route('admin.nonaktif_pelanggan', $user->id_user)); ?>" data-toggle="tooltip" title="Nonaktif Pelanggan">
                                                <i class="fa fa-ban"></i>
                                            </a>
                                        </td>
                                    <?php elseif($user->status_id == 4): ?>
                                        <td>
                                            <h5>
                                                <span class="badge badge-pill bg-danger me-1"><?php echo e($user->status->nama_status); ?></span>
                                            </h5>
                                        </td>)
                                    <?php endif; ?>
                                    <td>
                                        <a class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#myModal<?php echo e($user->id_user); ?>" data-toggle="tooltip" title="Lihat Langganan Pelanggan">
                                            <i style="color: white" class="fa fa-eye"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php echo e($users->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        $('.checkbox').on('click', function () {
            var ppn_id = $(this).prop('checked') === true ? 1 : 0;
            // alert(status);
            var user_id = $(this).data('id');
            // console.log(user_id);
            $.ajax({
                type: "GET",
                url: "<?php echo e(route('admin.changeppn')); ?>",
                data: {
                    id_user: user_id,
                    ppn_id: ppn_id,
                },
                cache: false,
                success: function (data) {
                    if(data.cek == 1){
                        alert(data.msg);
                    }else {
                        console.log('success: ' + data);
                    }
                },
                error: function (data) {
                    console.log('error:', data);
                }
            })
        })
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal'); ?>
    <?php $__currentLoopData = $langganan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal" id="myModal<?php echo e($lang['id']); ?>">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">

                    <!-- Modal Header -->
                    <div class="modal-header">
                        <h4 class="modal-title">Daftar Langganan <?php echo e($lang['name']); ?></h4>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"><span aria-hidden="true">&times;</span></button>
                    </div>

                    <!-- Modal body -->
                    <div class="modal-body">
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped mg-b-0 text-md-nowrap">
                                <thead style="text-align: center">
                                <tr>
                                    <th>No</th>
                                    <th>Alamat Pemasangan</th>
                                    <th>Jenis Langganan</th>
                                    <th>Tanggal Expired</th>
                                    <th>Status</th>
                                    <th>Aksi</th>
                                </tr>
                                </thead>
                                <tbody style="text-align: center">
                                <?php $__currentLoopData = $lang['langganan']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $langganan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($no+1); ?></td>
                                        <td><?php echo e($langganan->alamat_pasang); ?></td>
                                        <td><?php echo e($langganan->layanan->nama_layanan); ?></td>
                                        <td><?php echo e($langganan->tgl_lanjut); ?></td>
                                        <?php if($langganan->status_id == 1): ?>
                                            <td>
                                                <h5>
                                                    <span class="badge badge-pill bg-primary me-1"><?php echo e($langganan->status->nama_status); ?></span>
                                                </h5>
                                            </td>
                                            <td>
                                                <a class="btn btn-success" href="<?php echo e(route('admin.approvelangganan', $langganan->id_langganan)); ?>" data-toggle="tooltip" title="Approve">
                                                    <i class="fa fa-check"></i>
                                                </a>
                                                <a class="btn btn-danger" href="<?php echo e(route('admin.rejectlangganan', $langganan->id_langganan)); ?>" data-toggle="tooltip" title="Batal">
                                                    <i class="fa fa-ban"></i>
                                                </a>
                                            </td>
                                        <?php elseif($langganan->status_id == 2 || $langganan->status_id == 10): ?>
                                            <td>
                                                <h5>
                                                    <span class="badge badge-pill bg-success me-1">Aktif(proses pembayaran)</span>
                                                </h5>
                                            </td>
                                        <?php elseif($langganan->status_id == 3): ?>
                                            <td>
                                                <h5>
                                                    <span class="badge badge-pill bg-success me-1"><?php echo e($langganan->status->nama_status); ?></span>
                                                </h5>
                                            </td>
                                            <td>
                                                <a class="btn btn-warning" href="<?php echo e(route('admin.edit_langganan', $langganan->id_langganan)); ?>" data-toggle="tooltip" title="Edit Langganan">
                                                    <i class="fa fa-edit"></i>
                                                </a>
                                                <a class="btn btn-danger" href="<?php echo e(route('admin.nonaktif_langganan', $langganan->id_langganan)); ?>" data-toggle="tooltip" title="Nonaktif Langganan">
                                                    <i class="fa fa-ban"></i>
                                                </a>
                                            </td>
                                        <?php elseif($langganan->status_id == 4 || $langganan->status_id == 5): ?>
                                            <td>
                                                <h5>
                                                    <span class="badge badge-pill bg-danger me-1"><?php echo e($langganan->status->nama_status); ?></span>
                                                </h5>
                                            </td>
                                        <?php endif; ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <!-- Modal footer -->
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
                    </div>

                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.nowa',[
    'titlePage' => __('Daftar Pelanggan Aktif'),
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\borota\TA_SI\resources\views/dashboard/admin/user/pelanggan_cari.blade.php ENDPATH**/ ?>