<?php $__env->startSection('content'); ?>
    <div class="card">
        <form id="form" method="POST" action="<?php echo e(route('postpemesanan')); ?>">
            <?php echo csrf_field(); ?>

            <div class="card-header">
                <h4>Form Pemesanan</h4>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="form-group col-6">
                        <label for="kategori"><?php echo e(__('Kategori')); ?></label>
                        <select class="form-control selectric" id="kategori" name="id_kategori">
                            <option>Pilih Kategori</option>
                            <?php $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($kategori->id_kategori); ?>"><?php echo e($kategori->nama_kategori); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group col-6">
                        <label for="layanan"><?php echo e(__('Layanan')); ?></label>
                        <select class="form-control selectric" id="layanan" name="id_layanan"></select>
                    </div>
                </div>

                <div class="form-divider">
                    <?php echo e(__('Alamat Pemasangan')); ?>

                </div>

                <div class="row">
                    <div class="form-group col-6">
                        <label for="provinsi"><?php echo e(__('Provinsi')); ?></label>
                        <select class="form-control selectric" id="provinsi" name="id_provinsi">
                            <option>Pilih Provinsi</option>
                            <?php $__currentLoopData = $provincies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provinsi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($provinsi->id); ?>"><?php echo e($provinsi->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group col-6">
                        <label for="kabupaten"><?php echo e(__('Kabupaten/Kota')); ?></label>
                        <select class="form-control selectric" id="kabupaten" name="id_kabupaten"></select>
                    </div>
                </div>

                <div class="row">
                    <div class="form-group col-6">
                        <label for="kabupaten"><?php echo e(__('Kecamatan')); ?></label>
                        <select class="form-control selectric" id="kecamatan" name="id_kecamatan"></select>
                    </div>
                    <div class="form-group col-6">
                        <label for="kabupaten"><?php echo e(__('Kelurahan/Desa')); ?></label>
                        <select class="form-control selectric" id="desa" name="id_desa"></select>
                    </div>
                </div>

                <label for="alamat"><?php echo e(__('Alamat Lengkap')); ?></label>
                <textarea id="alamat" class="form-control <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="alamat" required autocomplete="alamat"></textarea>

                <div class="form-group">
                    <button type="submit" class="btn btn-primary btn-lg btn-block">
                        Create
                    </button>
                </div>

            </div>
        </form>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        $(function(){
            $.ajaxSetup({
                headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')}
            });

            $(function () {
                $('#kategori').on('change', function () {
                    var id_kategori = $('#kategori').val();
                    console.log(id_kategori);
                    $.ajax({
                        type: "POST",
                        url: "<?php echo e(route('getLayanan')); ?>",
                        data: {id_kategori: id_kategori},
                        cache: false,
                        success: function (msg) {
                            $('#layanan').html(msg);
                        },
                        error: function (data) {
                            console.log('error:', data);
                        }
                    })
                })
                $('#layanan').on('change',function (){
                    var id_layanan = $('#layanan').val();
                    console.log(id_layanan);
                })
                $('#provinsi').on('change',function (){
                    var id_provinsi = $('#provinsi').val();
                    console.log(id_provinsi)
                    $.ajax({
                        type : "POST",
                        url : "<?php echo e(route('getKabupaten')); ?>",
                        data : {id_provinsi:id_provinsi},
                        cache : false,
                        success: function (msg){
                            $('#kabupaten').html(msg);
                            $('#kecamatan').html('');
                            $('#desa').html('');
                        },
                        error: function (data){
                            console.log('error:',data);
                        }
                    })
                })
                $('#kabupaten').on('change',function (){
                    var id_kabupaten = $('#kabupaten').val();
                    console.log(id_kabupaten);
                    $.ajax({
                        type : "POST",
                        url : "<?php echo e(route('getKecamatan')); ?>",
                        data : {id_kabupaten:id_kabupaten},
                        cache : false,
                        success: function (msg){
                            $('#kecamatan').html(msg);
                            $('#desa').html('');
                        },
                        error: function (data){
                            console.log('error:',data);
                        }
                    })
                })
                $('#kecamatan').on('change',function (){
                    var id_kecamatan = $('#kecamatan').val();
                    console.log(id_kecamatan);
                    $.ajax({
                        type : "POST",
                        url : "<?php echo e(route('getDesa')); ?>",
                        data : {id_kecamatan:id_kecamatan},
                        cache : false,
                        success: function (msg){
                            $('#desa').html(msg);
                        },
                        error: function (data){
                            console.log('error:',data);
                        }
                    })
                })
                $('#desa').on('change',function (){
                    var id_desa = $('#desa').val();
                    console.log(id_desa);
                })
                $("#form").submit(function (e) {
                    e.preventDefault();
                    var id_layanan = $('#layanan').val();
                    var id_provinsi = $('#provinsi').val();
                    var id_kabupaten = $('#kabupaten').val();
                    var id_kecamatan = $('#kecamatan').val();
                    var id_desa = $('#desa').val();
                    var id_alamat = $('#alamat').val();
                    console.log(id_alamat);
                    $.ajax({
                        type: "POST",
                        url: "<?php echo e(route('postpemesanan')); ?>",
                        data: {
                            id_layanan: id_layanan,
                            id_provinsi: id_provinsi,
                            id_kabupaten: id_kabupaten,
                            id_kecamatan: id_kecamatan,
                            id_desa: id_desa,
                            id_alamat: id_alamat
                        },
                        cache: false,
                        success: function (data) {
                            console.log('success: ' + data);
                            window.location.href = "/pelanggan/data_langganan";
                        },
                        error: function (data) {
                            var errors = data.responseJSON;
                            console.log(errors);
                        }
                    })
                })
            })
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app',[
    'titlePage'=>__('Pemesanan'),
    'sub' => ' '
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\borota\pendataan-pelanggan\resources\views/dashboard/pelanggan/pemesanan.blade.php ENDPATH**/ ?>