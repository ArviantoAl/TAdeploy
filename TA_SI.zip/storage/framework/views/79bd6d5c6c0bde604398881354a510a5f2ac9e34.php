<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="col-12 col-lg-12">
            <div class="card">
                <div class="card-header">
                    <h4>Daftar Semua User</h4>
                </div>

                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-md">
                            <thead>
                            <th>No</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Username</th>
                            <th>Role</th>
                            <th>Alamat</th>
                            <th>No HP</th>
                            <th colspan="2">Action</th>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($no+1); ?></td>
                                    <td><?php echo e($user->name); ?></td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td><?php echo e($user->username); ?></td>
                                    <td><?php echo e($user->role->nama_role); ?></td>
                                    <td><?php echo e($user->alamat); ?></td>
                                    <td><?php echo e($user->no_hp); ?></td>
                                    <td>
                                        <a class="btn btn-warning" href="<?php echo e(route('admin.edituser', $user->id_user)); ?>">Edit</a>
                                    </td>
                                    <td>
                                        <form action="<?php echo e(route('admin.deleteuser', $user->id_user)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="_method" value="DELETE">
                                            <button class="btn btn-danger" type="submit">DELETE</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <a class="btn btn-success" href="<?php echo e(route('admin.tambahuser')); ?>">Tambah User</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app',[
    'titlePage' => __('Daftar User'),
    'sub' => ' '
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\borota\pendataan-pelanggan\resources\views/dashboard/admin/user/user.blade.php ENDPATH**/ ?>