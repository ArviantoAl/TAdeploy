<div class="main-sidebar">
    <aside id="sidebar-wrapper">
        <div class="sidebar-brand">
            <a href="index.html">Stisla</a>
        </div>
        <div class="sidebar-brand sidebar-brand-sm">
            <a href="index.html">St</a>
        </div>
        <ul class="sidebar-menu">
            <li class="menu-header">Dashboard</li>

            <?php if($titlePage == 'Dashboard Keuangan'): ?>
                <li class="active">
            <?php else: ?>
                <li>
                    <?php endif; ?>
                    <a class="nav-link" href="<?php echo e(route('teknisi.dashboard')); ?>"><i class="far fa-square"></i> <span>Dashboard</span></a></li>

                <li class="menu-header">User</li>

                <?php if($titlePage == 'Daftar User'): ?>
                    <li class="active">
                <?php else: ?>
                    <li>
                        <?php endif; ?>
                        <a class="nav-link" href="<?php echo e(route('teknisi.user')); ?>"><i class="fas fa-users"></i> <span>Daftar User</span></a></li>

                    <li class="menu-header">Layanan</li>

                    <?php if($titlePage == 'Daftar Layanan'): ?>
                        <li class="active">
                    <?php else: ?>
                        <li>
                            <?php endif; ?>
                            <a class="nav-link" href="<?php echo e(route('teknisi.layanan')); ?>"><i class="fas fa-users"></i> <span>Daftar Layanan</span></a></li>



                        <li class="menu-header">Langganan dan Invoice</li>

                        <?php if($titlePage == 'Daftar Langganan'): ?>
                            <li class="nav-item dropdown active">
                        <?php else: ?>
                            <li class="nav-item dropdown">
                                <?php endif; ?>
                                <a href="#" class="nav-link has-dropdown"><i class="fa fa-satellite-dish"></i> <span>Langganan</span></a>
                                <ul class="dropdown-menu">

                                    <?php if($sub == 'Semua Langganan'): ?>
                                        <li class="active">
                                    <?php else: ?>
                                        <li>
                                            <?php endif; ?>
                                            <a href="<?php echo e(route('teknisi.langganan')); ?>">Semua Langganan</a></li>

                                        <?php if($sub == 'Langganan Baru'): ?>
                                            <li class="active">
                                        <?php else: ?>
                                            <li>
                                                <?php endif; ?>
                                                <a href="<?php echo e(route('teknisi.langgananbaru')); ?>">Baru</a></li>

                                            <?php if($sub == 'Langganan Disetujui'): ?>
                                                <li class="active">
                                            <?php else: ?>
                                                <li>
                                                    <?php endif; ?>
                                                    <a href="<?php echo e(route('teknisi.langganansetuju')); ?>">Disetujui</a></li>

                                                <?php if($sub == 'Langganan Menunggu Pembayaran'): ?>
                                                    <li class="active">
                                                <?php else: ?>
                                                    <li>
                                                        <?php endif; ?>
                                                        <a href="<?php echo e(route('teknisi.langgananmenunggu')); ?>">Menunggu Pembayaran</a></li>

                                                    <?php if($sub == 'Langganan Aktif'): ?>
                                                        <li class="active">
                                                    <?php else: ?>
                                                        <li>
                                                            <?php endif; ?>
                                                            <a href="<?php echo e(route('teknisi.langgananaktif')); ?>">Aktif</a></li>

                                                        <?php if($sub == 'Langganan Kadaluarsa'): ?>
                                                            <li class="active">
                                                        <?php else: ?>
                                                            <li>
                                                                <?php endif; ?>
                                                                <a href="<?php echo e(route('teknisi.langganankadaluarsa')); ?>">Kadaluarsa</a></li>

                                                            <?php if($sub == 'Langganan Batal'): ?>
                                                                <li class="active">
                                                            <?php else: ?>
                                                                <li>
                                                                    <?php endif; ?>
                                                                    <a href="<?php echo e(route('teknisi.langgananbatal')); ?>">Batal</a></li>
                                </ul>
                            </li>

                            <?php if($titlePage == 'Daftar Invoice'): ?>
                                <li class="nav-item dropdown active">
                            <?php else: ?>
                                <li class="nav-item dropdown">
                                    <?php endif; ?>
                                    <a href="#" class="nav-link has-dropdown"><i class="fa fa-file-invoice"></i> <span>Invoice</span></a>
                                    <ul class="dropdown-menu">

                                        <?php if($sub == 'Semua Invoice'): ?>
                                            <li class="active">
                                        <?php else: ?>
                                            <li>
                                                <?php endif; ?>
                                                <a href="<?php echo e(route('teknisi.invoice')); ?>">Semua Invoice</a></li>

                                            <?php if($sub == 'Invoice Belum Dikirim'): ?>
                                                <li class="active">
                                            <?php else: ?>
                                                <li>
                                                    <?php endif; ?>
                                                    <a href="<?php echo e(route('teknisi.inv_belumkirim')); ?>">Belum Dikirim</a></li>

                                                <?php if($sub == 'Invoice Melebihi Batas Pembayaran'): ?>
                                                    <li class="active">
                                                <?php else: ?>
                                                    <li>
                                                        <?php endif; ?>
                                                        <a href="<?php echo e(route('teknisi.inv_melebihibatas')); ?>">Melebihi Batas Bayar</a></li>

                                                    <?php if($sub == 'Invoice Menunggu Pembayaran'): ?>
                                                        <li class="active">
                                                    <?php else: ?>
                                                        <li>
                                                            <?php endif; ?>
                                                            <a href="<?php echo e(route('teknisi.inv_menunggu')); ?>">Menunggu Pembayaran</a></li>

                                                        <?php if($sub == 'Invoice Lunas'): ?>
                                                            <li class="active">
                                                        <?php else: ?>
                                                            <li>
                                                                <?php endif; ?>
                                                                <a href="<?php echo e(route('teknisi.inv_lunas')); ?>">Lunas</a></li>

                                                            <?php if($sub == 'Invoice Tidak Dibayar/Batal'): ?>
                                                                <li class="active">
                                                            <?php else: ?>
                                                                <li>
                                                                    <?php endif; ?>
                                                                    <a href="<?php echo e(route('teknisi.inv_batal')); ?>">Tidak Dibayar/Batal</a></li>
                                    </ul>
                                </li>
        </ul>
    </aside>
</div>
<?php /**PATH C:\Users\borota\TA_SI\resources\views/layouts/sidebar_keuangan.blade.php ENDPATH**/ ?>
