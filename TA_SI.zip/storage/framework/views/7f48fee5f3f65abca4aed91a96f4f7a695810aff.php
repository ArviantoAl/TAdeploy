<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="col-12 col-lg-12">
            <div class="card">
                <div class="card-header">
                    <h4><?php echo e($header); ?></h4>
                </div>

                <div class="card-body">
                    <div class="table-responsive">
                        <?php if(count($langganans)==0): ?>
                            <p>Tidak ada data</p>
                        <?php elseif(count($langganans)>0): ?>
                            <table class="table table-bordered table-md">
                                <thead>
                                <th>No</th>
                                <th>Nama Pelanggan</th>
                                <th>Alamat Pemasangan</th>
                                <th>Jenis Langganan</th>
                                <th>Status</th>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $langganans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $langganan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($no+1); ?></td>
                                        <td><?php echo e($langganan->pelanggan->name); ?></td>
                                        <td><?php echo e($langganan->alamat_pasang); ?></td>
                                        <td><?php echo e($langganan->layanan->nama_layanan); ?></td>
                                        <?php if($langganan->status == 0): ?>
                                            <td>Langganan Baru</td>
                                        <?php elseif($langganan->status == 1): ?>
                                            <td>Langganan Tidak disetujui</td>
                                        <?php elseif($langganan->status == 2): ?>
                                            <td>Langganan Disetujui</td>
                                        <?php elseif($langganan->status == 3): ?>
                                            <td>Langganan menunggu pembayaran, Cek Email untuk Melihat Invoice/Tagihan Anda</td>
                                        <?php elseif($langganan->status == 4): ?>
                                            <td>Langganan Aktif</td>
                                        <?php endif; ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        <?php endif; ?>
                        <a class="btn btn-success" href="<?php echo e(route('pelanggan.pemesanan')); ?>">Tambah Langganan</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app',[
    'titlePage' => __('Daftar Langganan'),
    'sub' => $header
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\borota\pendataan-pelanggan\resources\views/dashboard/pelanggan/langganan.blade.php ENDPATH**/ ?>