<?php $__env->startSection('content'); ?>
    <!-- breadcrumb -->
    <div class="breadcrumb-header justify-content-between">
        <div class="left-content">
            <span class="main-content-title mg-b-0 mg-b-lg-1">Edit Perangkat BTS</span>
        </div>
        <div class="justify-content-center mt-2">
            <ol class="breadcrumb">
                <li class="breadcrumb-item tx-15"><a href="javascript:void(0);">Data Perangkat BTS</a></li>
                <li class="breadcrumb-item active" aria-current="page">Edit Perangkat BTS</li>
            </ol>
        </div>
    </div>
    <!-- /breadcrumb -->

    <div class="col-lg-12 col-xl-12 col-md-12 col-sm-12">
        <div class="card  box-shadow-0 ">
            <div class="card-header">
                <h4 class="card-title mb-1">Form Edit Perangkat BTS</h4>
                <p class="mb-2">Isi data form berikut untuk mengubah Perangkat BTS.</p>
            </div>
            <div class="card-body pt-0">
                <?php if(session()->has('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <strong><?php echo e(session()->get('error')); ?></strong>
                        <button aria-label="Close" class="btn-close" data-bs-dismiss="alert" type="button"><span aria-hidden="true">&times;</span></button>
                    </div>
                <?php endif; ?>
                    <form method="POST" action="<?php echo e(route('admin.posteditbts', $bts->id_bts)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                    <div class="form-group">
                        <label for="nama" class="form-label">Nama Perangkat</label>
                        <input class="form-control" id="nama" name="nama" value="<?php echo e($bts->nama_bts); ?>" placeholder="Masukkan Nama Perangkat" type="text" required autocomplete="nama" autofocus>
                    </div>
                    <div class="row">
                        <div class="form-group col-4">
                            <label for="lokasi" class="form-label">Lokasi BTS</label>
                            <select name="lokasi" id="lokasi" class="form-control form-select select2" data-bs-placeholder="Pilih Lokasi BTS" required>
                                <option value="0">Pilih Lokasi BTS</option>
                                <?php $__currentLoopData = $lokasis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($l->id_master); ?>" <?php echo e($bts->lokasi_id == $l->id_master ? 'selected' : ''); ?>><?php echo e($l->nama_lokasi); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group col-4">
                            <label for="alamat" class="form-label">Detail Alamat</label>
                            <textarea class="form-control" name="alamat" id="alamat" placeholder="Masukkan Alamat Lengkap" required><?php echo e($bts->detail_alamat); ?></textarea>
                        </div>
                        <div class="form-group col-4">
                            <label for="koordinat" class="form-label">Koordinat Lokasi</label>
                            <input class="form-control" id="koordinat" name="koordinat" value="<?php echo e($bts->latitude); ?>,<?php echo e($bts->longitude); ?>" placeholder="ex. -7.551311,110.854192" type="text" autocomplete="koordinat" autofocus>
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-group col-4">
                            <label for="jenis" class="form-label">Jenis BTS</label>
                            <select name="jenis" id="jenis" class="form-control form-select select2" data-bs-placeholder="Pilih Jenis BTS" required>
                                <option value="0">Pilih Lokasi BTS</option>
                                <?php $__currentLoopData = $jeniss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($j->id_jenis); ?>" <?php echo e($bts->jenis_id == $j->id_jenis ? 'selected' : ''); ?>><?php echo e($j->nama_perangkat); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group col-4">
                            <label for="k_frekuensi" class="form-label">Kategori Frekuensi BTS</label>
                            <select name="k_frekuensi" id="k_frekuensi" class="form-control form-select select2" data-bs-placeholder="Pilih Kategori Frekuensi BTS" required>
                                <option value="0">Pilih Kategori Frekuensi BTS</option>
                                <?php $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($k->id_kategori); ?>" <?php echo e($bts->kategori_id == $k->id_kategori ? 'selected' : ''); ?>><?php echo e($k->kategori_frekuensi); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group col-4">
                            <label for="frekuensi" class="form-label">Frekuensi</label>
                            <input class="form-control" id="frekuensi" name="frekuensi" value="<?php echo e($bts->frekuensi); ?>" placeholder="Masukkan Frekuensi" type="number" required autocomplete="frekuensi" autofocus>
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-group col-6">
                            <label for="ssid" class="form-label">SSID</label>
                            <input class="form-control" id="ssid" name="ssid" value="<?php echo e($bts->ssid); ?>" placeholder="Masukkan SSID" type="text" required autocomplete="ssid" autofocus>
                        </div>
                        <div class="form-group col-6">
                            <label for="ip" class="form-label">IP Address</label>
                            <input class="form-control" id="ip" name="ip" value="<?php echo e($bts->ip); ?>" placeholder="Masukkan IP BTS" type="text" required autocomplete="ip" autofocus>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary mt-3 mb-0">Submit</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.nowa',[
    'titlePage' => __('Edit Perangkat BTS'),
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\borota\TA_SI\resources\views/dashboard/admin/bts/edit_bts.blade.php ENDPATH**/ ?>