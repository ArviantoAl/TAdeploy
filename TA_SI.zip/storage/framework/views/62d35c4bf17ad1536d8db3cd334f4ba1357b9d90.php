<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="col-12 col-lg-12">
            <div class="card">
                <div class="card-header">
                    <h4><?php echo e($header); ?></h4>
                </div>

                <div class="card-body">
                    <div class="table-responsive">
                        <?php if(count($invoices)==0): ?>
                            <p>Tidak ada data</p>
                        <?php elseif(count($invoices)>0): ?>
                            <table class="table">
                                <thead>
                                <th>Id Invoice</th>
                                <th>Nama Pelanggan</th>
                                <th>Tanggal Terbit</th>
                                <th>Tanggal Tempo</th>
                                <th>Harga Bayar</th>
                                <th>Status</th>
                                <th>Action</th>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($invoice->id_invoice); ?></td>
                                        <td><?php echo e($invoice->pelanggan->name); ?></td>
                                        <td><?php echo e($invoice->tgl_terbit); ?></td>
                                        <td><?php echo e($invoice->tgl_tempo); ?></td>
                                        <td><?php echo e($invoice->harga_bayar); ?></td>
                                        <?php if($invoice->status == 0): ?>
                                            <td><div class="badge badge-info">Belum Dikirim</div></td>
                                            <td>
                                                <a class="btn btn-success" href="<?php echo e(route('admin.kiriminvoice', $invoice->id_invoice)); ?>">Kirim Invoice</a>
                                            </td>
                                        <?php elseif($invoice->status == 1): ?>
                                            <?php if($tanggal>=$invoice->tgl_tempo): ?>
                                                <td><div class="badge badge-warning">Melebihi Batas Pembayaran</div></td>
                                                <td>
                                                    <a class="btn btn-danger" href="<?php echo e(route('admin.tolakpembayaran', $invoice->id_invoice)); ?>">Tolak</a>
                                                </td>
                                            <?php elseif($tanggal<=$invoice->tgl_tempo): ?>
                                                <td><div class="badge badge-warning">Menunggu Pembayaran</div></td>
                                                <td>
                                                    <a class="btn btn-success" href="<?php echo e(route('admin.approvepembayaran', $invoice->id_invoice)); ?>">Invoice Terbayar</a>

                                                    <a class="btn btn-danger" href="<?php echo e(route('admin.tolakpembayaran', $invoice->id_invoice)); ?>">Tolak</a>
                                                </td>
                                            <?php endif; ?>
                                        <?php elseif($invoice->status == 2): ?>
                                            <td><div class="badge badge-success">Lunas</div></td>
                                        <?php elseif($invoice->status == 3): ?>
                                            <td><div class="badge badge-danger">Tidak Dibayar</div></td>
                                        <?php endif; ?>
                                        <td>
                                            <a class="btn btn-success" href="<?php echo e(route('admin.printinv', $invoice->id_invoice)); ?>">Cetak</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app',[
    'titlePage' => __('Daftar Invoice'),
    'sub' => $header
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\borota\pendataan-pelanggan\resources\views/dashboard/admin/invoice.blade.php ENDPATH**/ ?>