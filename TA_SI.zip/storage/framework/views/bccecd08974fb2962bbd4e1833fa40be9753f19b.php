<?php $__env->startSection('content'); ?>
    <!-- breadcrumb -->
    <div class="breadcrumb-header justify-content-between">
        <div class="left-content">
            <span class="main-content-title mg-b-0 mg-b-lg-1">Daftar Langganan</span>
        </div>
        <div class="justify-content-center mt-2">
            <ol class="breadcrumb">
                <li class="breadcrumb-item tx-15"><a href="javascript:void(0);">Data Layanan</a></li>
                <li class="breadcrumb-item active" aria-current="page">Daftar Layanan</li>
            </ol>
        </div>
    </div>
    <!-- /breadcrumb -->

    <!-- Row -->
    <div class="row row-sm">
        <div class="col-lg-12">
            <div class="card custom-card overflow-hidden">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped mg-b-0 text-md-nowrap">
                            <thead style="text-align: center">
                            <tr>
                                <th>No</th>
                                <th>Alamat Pemasangan</th>
                                <th>Jenis Langganan</th>
                                <th>Status</th>
                            </tr>
                            </thead>
                            <tbody style="text-align: center">
                            <?php $__currentLoopData = $langganans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no => $langganan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($no+1); ?></td>
                                    <td><?php echo e($langganan->alamat_pasang); ?></td>
                                    <td><?php echo e($langganan->layanan->nama_layanan); ?></td>
                                    <?php if($langganan->status_id == 1): ?>
                                        <td>
                                            <h5>
                                                <span class="badge badge-pill bg-primary me-1"><?php echo e($langganan->status->nama_status); ?></span>
                                            </h5>
                                        </td>
                                        <td>
                                            <a class="btn btn-success" href="<?php echo e(route('admin.approvelangganan', $langganan->id_langganan)); ?>" data-toggle="tooltip" title="Approve">
                                                <i class="fa fa-check"></i>
                                            </a>
                                        </td>
                                    <?php elseif($langganan->status_id == 2): ?>
                                        <td>
                                            <h5>
                                                <span class="badge badge-pill bg-warning me-1"><?php echo e($langganan->status->nama_status); ?></span>
                                            </h5>
                                        </td>
                                    <?php elseif($langganan->status_id == 3): ?>
                                        <td>
                                            <h5>
                                                <span class="badge badge-pill bg-success me-1"><?php echo e($langganan->status->nama_status); ?></span>
                                            </h5>
                                        </td>
                                    <?php elseif($langganan->status_id == 4): ?>
                                        <td>
                                            <h5>
                                                <span class="badge badge-pill bg-danger me-1"><?php echo e($langganan->status->nama_status); ?></span>
                                            </h5>
                                        </td>
                                    <?php elseif($langganan->status_id == 5): ?>
                                        <td>
                                            <h5>
                                                <span class="badge badge-pill bg-danger me-1"><?php echo e($langganan->status->nama_status); ?></span>
                                            </h5>
                                        </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php echo e($langganans->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.nowa',[
    'titlePage' => __('Daftar Langganan'),
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\borota\TA_SI\resources\views/dashboard/pelanggan/langganan.blade.php ENDPATH**/ ?>